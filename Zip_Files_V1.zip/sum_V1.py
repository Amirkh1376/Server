# Initialize the sum variable
sum = 0

# Loop through numbers from 1 to 10
for num in range(1, 11):
    # Add the current number to the sum
    sum += num

# Print the final sum
print("The sum of numbers from 1 to 10 is:", sum)