# Initialize the sub variable
sub = 0

# Loop through numbers from 1 to 10
for num in range(1, 11):
    # subtracte  the current number from the sub
    sub -= num

# Print the final subtraction 
print("The subtraction of numbers from 1 to 10 is:", sub)